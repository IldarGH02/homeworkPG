import './App.css';
import Categories from './components/Categories/Categories';

const App = () => {
  return (
    <div className="App">
      <div className='container'>
        <Categories/>
      </div>
    </div>
  );
}

export default App;
